<?php
  session_start();
  if(!isset($_SESSION["cus_id"])) {
      header("Location:index.php");      
  }  
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Home Page</title>
<meta charset="UTF-8">
<link href="css/date_picker.css" rel="stylesheet">
<script src="js/jquery.js"></script>
<script src="js/jquery_ui.js"></script>
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">NorthEast Tours</a></h1>
      <h2>Explore the Northeast</h2>
    </div>
    <form action="#" method="post">
      <fieldset>
        <legend>Search:</legend>
        <input type="text" value="Search Our Website&hellip;" onFocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;">
        <input type="submit" id="sf_submit" value="submit">
      </fieldset>
    </form>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Packages</a></li>
        <li><a href="#">Collections</a></li>
        <li><a href="#">services</a></li>
        <li><a href="logout.php"> LOGOUT </a></li>        
      </ul>
    </nav>
  </header>
</div>

<!-- content -->
<div class="wrapper row2">
  <?php echo "WELCOME ".$_SESSION["cus_name"]. ", THIS IS YOUR PROFILE :)"; ?>
  <div id="container" class="clear">
    <!-- content body -->
    <section id="slider"><a href="#"><img src="images/assam_0.jpg" alt=""></a></section>
    <section id="shout">
      <p>
      	<form name="search_form" action="search_hotels.php" method="post">
	From : 	<select name="source">
	          <option selected="true" disabled="disabled">Select</option>  
	          <?php
	          	  require_once 'connect.php';
	              $sql   = "SELECT * FROM cities";
	              $result = mysqli_query($conn,$sql);
	           
	              while($row = mysqli_fetch_array($result)){
	                echo '<option value='.$row['city_id'].'>'.$row['city_name'].'</option>';         
	              }
	            ?>                      
	        </select>
	To : 	<select name="destination">
	          <option selected="true" disabled="disabled">Select</option>  
	          <?php
	          	  require_once 'connect.php';
	              $sql   = "SELECT * FROM cities";
	              $result = mysqli_query($conn,$sql);
	           
	              while($row = mysqli_fetch_array($result)){
	                echo '<option value='.$row['city_id'].'>'.$row['city_name'].'</option>';         
	              }
	            ?>                      
	        </select>
	<label for="from">Departure</label>  <input type="text" class="datepicker" id="from" name="from"/> 
	<label for="to">Arrival</label>  <input type="text" class="datepicker" id="to" name="to"/>
	<input type="submit" name="subBtn" value="Search">
</form>
      </p>
    </section>
    <!-- main content -->
    <div id="homepage">
      <!-- services area -->
      <h1>Services We Offer</h1>
      <section id="services" class="clear">
        
      </section>
      
    </div>
    <!-- / content body -->
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  
</div>

<script type="text/javascript">
 	var dateToday = new Date();
	var dates = $("#from").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "+1w",
    changeMonth: true,
    numberOfMonths: 2,
    minDate: dateToday,
      onSelect: function(selectedDate) {
        var option = this.id == "from" ? "minDate" : "maxDate",
            instance = $(this).data("datepicker"),
            date = $.datepicker.parseDate(instance.settings.dateFormat || $.datepicker._defaults.dateFormat, selectedDate, instance.settings);
        dates.not(this).datepicker("option", option, date);
    }
});	
</script>
<script type="text/javascript">
 	var dateToday = new Date();
	var dates = $("#to").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "+1w",
    changeMonth: true,
    numberOfMonths: 2,
    minDate: 0,
        onSelect: function(selectedDate) {
        var option = this.id == "to" ? "minDate" : "maxDate",
            instance = $(this).data("datepicker"),
            date = $.datepicker.parseDate(instance.settings.dateFormat || $.datepicker._defaults.dateFormat, selectedDate, instance.settings);
        dates.not(this).datepicker("option", option, date);
    }
});	
</script>

</body>
</html>