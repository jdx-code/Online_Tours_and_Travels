<?php
	require_once 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN- HOTELS</title>
</head>
<body>
	ADD NEW HOTEL <br>
	<form name="subject_form" action="add_hotel.php" method="post">
		Hotel Name : <input type="text" name="hotel_name" value=""><br>
    Category :   <input type="radio" name="hotel_category" value="3 Star"> 3 Star
                 <input type="radio" name="hotel_category" value="4 Star"> 4 Star
                 <input type="radio" name="hotel_category" value="5 Star"> 5 Star<br>
    Total Rooms :<input type="text" name="total_rooms" value=""><br>
    Rate per room :<input type="text" name="rate_per_room" value=""><br>
    City :       <select name="city_id">
                    <option selected="true" disabled="disabled">Select</option>  
                    <?php          	  
                        $sql   = "SELECT * FROM cities";
                        $result = mysqli_query($conn,$sql);
                     
                        while($row = mysqli_fetch_array($result)){
                          echo '<option value='.$row['city_id'].'>'.$row['city_name'].'</option>';         
                        }
                      ?>                      
                  </select> </br>
    Hotel Description : <textarea rows="5" cols="25" name="hotel_desc"></textarea><br>
                  <input type="submit" name="submitBtn" value="ADD HOTEL">
	</form>

	<hr>

	<table class="table table-striped">
    <thead>
      <tr>
      	
      	<th scope="col">HOTEL</th>
        <th scope="col">CATEGORY</th>
        <th scope="col">CITY</th>        
        <th scope="col">TOTAL ROOMS</th>
        <th scope="col">DESCRIPTION</th>
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM hotel_info, cities WHERE hotel_info.city_id = cities.city_id";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
    ?>
    <tbody>
      <tr>
        <td>
          <?php
            echo $row['hotel_name'];
          ?>
        </td>
        <td>
          <?php
            echo $row['hotel_category'];
          ?>
        </td>
        <td>
          <?php
            echo $row['city_name'];
          ?>
        </td>
        <td>
          <?php
            echo $row['total_rooms'];
          ?>
        </td>       
        <td>
          <?php
            echo $row['hotel_desc'];
          ?>
        </td>
        
                      
        <td>
        	<a type="button" class="btn btn-danger" href="update_hotel.php?hotel_id=<?php echo $row['hotel_id'];?>">Update</a>
        </td>
        <td>
          <a type="button" class="btn btn-danger" href="del_this_hotel.php?hotel_id=<?php echo $row['hotel_id'];?>">Delete</a>
        </td>

      <?php
      }
      ?>
      </tr>

    </tbody>
  </table>



</body>
</html>