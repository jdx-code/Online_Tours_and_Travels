<?php
session_start();
require_once 'connect.php';
$cus_u_name   = $_POST['cus_u_name'];
$cus_password = $_POST['cus_password'];
$sql   = "SELECT * FROM customer WHERE cus_u_name ='$cus_u_name' AND cus_password ='$cus_password'";
$result = mysqli_query($conn,$sql);
$count  = mysqli_num_rows($result);
$row    = mysqli_fetch_array($result);
if($count==1){
  $_SESSION["cus_id"] = $row[cus_id];
  $_SESSION["cus_name"] = $row[cus_name];
  header("location: user_profile.php");
}
else{
  $error = "Your username and password is incorrect";
  echo $error;
}
?>
