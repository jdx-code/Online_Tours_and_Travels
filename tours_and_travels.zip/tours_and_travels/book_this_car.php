<?php
	require_once 'connect.php';

	$cus_id    	  	  = $_POST['cus_id'];
	$car_no 	  	  = $_POST['car_no'];
	$source  		  = $_POST['source'];
	$destination 	  = $_POST['destination'];	
	$date_of_booking  = date('d-m-Y');


	$sql = "INSERT INTO car_booking (book_id, cus_id, car_no, source, destination, date_of_booking) VALUES (DEFAULT,'$cus_id','$car_no','$source','$destination','$date_of_booking')";
	$query = mysqli_query($conn,$sql);
	header("Location: car_book_msg.php");	
?>
