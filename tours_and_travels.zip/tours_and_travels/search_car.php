<?php
  session_start();
  if(!isset($_SESSION["cus_id"])) {
      header("Location:index.php");      
  }
	require_once 'connect.php';
	$from_city 	 = $_GET['from_city'];
  $to_city     = $_GET['to_city'];
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Home Page</title>
<meta charset="UTF-8">
<link href="css/date_picker.css" rel="stylesheet">
<script src="js/jquery.js"></script>
<script src="js/jquery_ui.js"></script>
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">NorthEast Tours</a></h1>
      <h2>Explore the Northeast</h2>
    </div>
    <form action="#" method="post">
      <fieldset>
        <legend>Search:</legend>
        <input type="text" value="Search Our Website&hellip;" onFocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;">
        <input type="submit" id="sf_submit" value="submit">
      </fieldset>
    </form>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Packages</a></li>
        <li><a href="#">Collections</a></li>
        <li><a href="#">services</a></li>
        <li><a href="logout.php"> LOGOUT </a></li>        
      </ul>
    </nav>
  </header>
</div>

<!-- content -->
<div class="wrapper row2">
  <?php echo "WELCOME ".$_SESSION["cus_name"]. ""; ?>
  <div id="container" class="clear">
    <!-- content body -->
    <section id="slider"><a href="#"><img src="images/assam_0.jpg" alt=""></a></section>
    <section id="shout">
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">CAR NO</th>
            <th scope="col">CAR TYPE</th>
            <th scope="col">CAR </th>
            <!-- <th scope="col">RATE PER DAY</th> -->
            <th scope="col">OWNER/DRIVER</th>
          </tr>
        </thead>

        <?php
          $sql = "SELECT * FROM trips, cars WHERE trips.car_no = cars.car_no AND trips.from_city = '$from_city' AND trips.to_city = '$to_city'";
          $result = mysqli_query($conn,$sql);
          while($row = mysqli_fetch_array($result)){
        ?>
        <tbody>
          <tr>
            <td>
              <?php
                echo $row['car_no'];
              ?>
            </td>
            <td>
              <?php
                echo $row['car_type'];
              ?>
            </td>
            <td>
              <?php
                echo $row['car_brand'];
              ?>
            </td>
            <!-- <td>
              <?php
                echo $row['per_day_rate'];
              ?>
            </td> -->
            <td>
              <?php
                echo $row['car_owner'];
              ?>
            </td>

            <form name="car_booking_form" action="book_this_car.php" method="post">
              <input type="hidden" name="cus_id" value="<?php echo $_SESSION['cus_id'];?>">
              <input type="hidden" name="car_no" value="<?php echo $row['car_no'];?>">
              <input type="hidden" name="source" value="<?php echo $from_city;?>">
              <input type="hidden" name="destination" value="<?php echo $to_city;?>">
              <td> 
                <input type="submit" name="submitBtn" value="Book Car">         
              </td>
            </form>   

          <?php
          }
          ?>
          </tr>

        </tbody>
      </table>
    </section>
    <!-- main content -->
    <div id="homepage">
      <!-- services area -->
     
      <section id="services" class="clear">
        
    </div>
    <!-- / content body -->
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">Tours & Travels</a></p>
    <p class="fl_right">Designed for <a target="_blank" href="#" title="Tours & Travels">Tours & Travels</a></p>
  </footer>
</div>
</body>
</html>