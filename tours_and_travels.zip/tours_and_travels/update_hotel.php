<?php
  require_once 'connect.php';
  $hotel_id = $_GET['hotel_id'];
?>

<form name="up_cus_form" action="update_this_hotel.php" method="post">
  <table class="table table-striped">
    <thead>
      <tr>
        <!-- <th scope="col">Category ID</th> -->
        <th scope="col">Hotel Name</th>
        <!-- <th scope="col">Added On</th -->        
        <th scope="col">Category</th>
        <th scope="col">Rooms</th>
        <!-- <th scope="col">Added On</th -->                
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM hotel_info where hotel_id = '$hotel_id'";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
    ?>
    
    <tbody>
      <tr>       	
        <td>
          	<input type="text" name="hotel_name" value="<?php echo $row['hotel_name'];?>">
        </td> 
        <td>
        	<input type="text" name="hotel_category" value="<?php echo $row['hotel_category'];?>">
        </td> 
        <td>
        	<input type="text" name="total_rooms" value="<?php echo $row['total_rooms'];?>">
        </td>        
        	<input type="hidden" name="hotel_id" value="<?php echo $row['hotel_id'];?>">
           	
        <td>
          	<input type="submit" name="update" value"UPDATE">
        </td>
      </tr>
     <?php
     }
    ?> 
    </tbody>       
  </table>
</form>