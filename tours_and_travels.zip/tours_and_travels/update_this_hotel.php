<?php

  require_once 'connect.php';

  $hotel_id     = $_POST['hotel_id'];
  $hotel_name   = $_POST['hotel_name'];
  $hotel_category   = $_POST['hotel_category'];
  $total_rooms    = $_POST['total_rooms'];
  
  $sql   =  "UPDATE hotel_info SET              
             hotel_name  = '$hotel_name',
             hotel_category = '$hotel_category',
             total_rooms = '$total_rooms'
             WHERE hotel_id = '$hotel_id'";
  $query = mysqli_query($conn,$sql);
  header('Location: hotels.php');
?>