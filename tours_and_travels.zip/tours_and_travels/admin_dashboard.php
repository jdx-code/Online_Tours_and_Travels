<?php
  session_start();
  if(!isset($_SESSION["admin_id"])) {
      header("Location:index.php");      
  }
  echo "WELCOME ".$_SESSION["admin_name"]. ", THIS IS YOUR ADMIN DASHBOARD :)";
?>
<!DOCTYPE html>
<html>
<head>
	<title> ADMIN DASHBOARD</title>
</head>
<body>
	<p></p>
	<a href="hotels.php">HOTELS INFO</a><br>
	<a href="cars.php">CARS INFO</a><br>
	<a href="customers.php">CUSTOMERS INFO</a><br>
	<a href="logout.php">LOGOUT</a>
</body>
</html>