<?php
 $hostname="localhost";
 $username="root";
 $database="db_tours_and_travels";
 $password="";

 $conn = mysqli_connect($hostname,$username,$password,$database);
 if(!$conn){
 die("could not connect database...");
 }
?>
