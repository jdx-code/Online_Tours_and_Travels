<?php
    require_once 'connect.php';
    $car_no = $_GET['car_no'];
?>
ADD NEW CARS <br>
	<form name="trip_form" action="add_trip.php" method="post">
    Car No   :  <input type="text" name="car_no" value="<?php echo $car_no;?>" readonly="readonly"><br>
    From :  <select name="from_city">
                  <option selected="true" disabled="disabled">Select</option>  
                  <?php                      
                      $sql   = "SELECT * FROM cities";
                      $result = mysqli_query($conn,$sql);
                   
                      while($row = mysqli_fetch_array($result)){
                        echo '<option value='.$row['city_id'].'>'.$row['city_name'].'</option>';         
                      }
                    ?>                      
                </select>
    From :  <select name="to_city">
              <option selected="true" disabled="disabled">Select</option>  
              <?php                  
                  $sql   = "SELECT * FROM cities";
                  $result = mysqli_query($conn,$sql);
               
                  while($row = mysqli_fetch_array($result)){
                    echo '<option value='.$row['city_id'].'>'.$row['city_name'].'</option>';         
                  }
                ?>                      
            </select>
               
            <input type="submit" name="submitBtn" value="ADD CAR">
	</form>

	<hr>