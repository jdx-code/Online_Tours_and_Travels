<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
</head>
<body>

<?php
  session_start();
  if(!isset($_SESSION["cus_id"])) {
      header("Location:index.php");
      echo "You must be logged in before booking";      
  }
  require_once 'connect.php';
  $hotel_id      = $_GET['hotel_id'];
  $rate_per_room = $_GET['rate_per_room'];
  $from_city      = $_GET['from_city'];
  $to_city      = $_GET['to_city'];

?>
 
<p>
<form name="search_form" action="hotel_payment.php" method="post">
  
          <input type="hidden" name="cus_id" value="<?php echo $_SESSION['cus_id'];?>">
          <input type="hidden" name="hotel_id" value="<?php echo $hotel_id;?>">
          <input type="hidden" name="from_city" value="<?php echo $from_city;?>">
          <input type="hidden" name="to_city" value="<?php echo $to_city;?>">

      No. of rooms : 
          <select name="rooms_booked" id="rooms_booked">
          <option selected="true" disabled="disabled">Select</option>  
        <?php
          $sql   = "SELECT * FROM hotel_info WHERE hotel_id = '$hotel_id'";
          $result = mysqli_query($conn,$sql);            
          while($row = mysqli_fetch_array($result)){
        ?>
          
          <?php  
            {
              for ($i = 1; $i <= $row['available_rooms']; $i++)
              echo '<option value='.$i.'>'.$i.'</option>';         
            }
          ?>

          <input type="hidden" name="available_rooms" value="<?php echo $row['available_rooms'];?>">
        <?php
          }
        ?>                      
          </select> <br>

      Per Room Rate :<input type="text" name="rate_per_room" id="rate_per_room" value="<?php echo $rate_per_room;?>" readonly > <br>
      Total Amount : <input type="text" name="total_amount" class="total_amount" id="total_amount" value="" readonly/> <br>
  <input type="submit" name="subBtn" value="Proceed to Payment">
</form>
</p>

<script type="text/javascript">

    $('select').on('change', function(){

    var rooms_booked  = this.value;
    var rate_per_room = $("#rate_per_room").val();
    var total_amount  = parseInt(rooms_booked) * parseInt(rate_per_room);
    $('#total_amount').val(total_amount);
    //alert(total_amount);
});

</script>
</body>
</html>