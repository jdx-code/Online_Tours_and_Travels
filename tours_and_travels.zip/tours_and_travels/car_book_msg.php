<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>
		Car Booked Successfully !!
	</p>
	<p>
		<a href="user_profile.php">Home</a>
	</p>
</html>