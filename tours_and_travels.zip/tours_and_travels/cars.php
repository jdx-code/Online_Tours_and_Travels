<?php
	require_once 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN- CARS</title>
</head>
<body>
	ADD NEW CARS <br>
	<form name="subject_form" action="add_car.php" method="post">
    Car No   :  <input type="text" name="car_no" value=""><br>
    Car Type :  <input type="radio" name="car_type" value="Hatchback"> Hatchback
                <input type="radio" name="car_type" value="Sedan"> Sedan
                <input type="radio" name="car_type" value="SUV  "> SUV<br>
    Brand :     <input type="text" name="car_brand" value=""><br>
		Owner :     <input type="text" name="car_owner" value=""><br>
    Phone :     <input type="text" name="owner_ph" value=""><br> 
    Address : 
                <textarea rows="5" cols="25" name="owner_address"></textarea><br>
    Driver :    <input type="text" name="car_driver" value=""><br>
    Phone :     <input type="text" name="driver_ph" value=""><br>  
    Address : 
                <textarea rows="5" cols="25" name="driver_address"></textarea><br>              
                <input type="submit" name="submitBtn" value="ADD CAR">
	</form>

	<hr>

	<table class="table table-striped">
    <thead>
      <tr>
      	<th scope="col">CAR No.</th>
      	<th scope="col">CAR</th>
        <th scope="col">TYPE</th>
        <th scope="col">OWNER</th>
        <th scope="col">PHONE</th>
        <th scope="col">ADDRESS</th>
        <th scope="col">DRIVER</th>
        <th scope="col">PHONE</th>
        <th scope="col">ADDRESS</th>
        <th scope="col">STATUS</th>
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM cars";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
    ?>
    <tbody>
      <tr>
        <td>
          <?php
            echo $row['car_no'];
          ?>
        </td>
        <td>
          <?php
            echo $row['car_brand'];
          ?>
        </td>
        <td>
          <?php
            echo $row['car_type'];
          ?>
        </td>
        <td>
          <?php
            echo $row['car_owner'];
          ?>
        </td>
        <td>
          <?php
            echo $row['owner_ph'];
          ?>
        </td>
        <td>
          <?php
            echo $row['owner_address'];
          ?>
        </td>
         <td>
          <?php
            echo $row['car_driver'];
          ?>
        </td>
         <td>
          <?php
            echo $row['driver_ph'];
          ?>
        </td>
         <td>
          <?php
            echo $row['driver_address'];
          ?>
        </td>
         <td>
          <?php
            echo $row['car_status'];
          ?>
        </td>
        
                      
        <td>
        	<a type="button" class="btn btn-danger" href="schedule_trip.php?car_no=<?php echo $row['car_no'];?>">Update</a>
        </td>
        <td>
          <a type="button" class="btn btn-danger" href="del_course.php?car_no=<?php echo $row['car_no'];?>">Delete</a>
        </td>

      <?php
      }
      ?>
      </tr>

    </tbody>
  </table>



</body>
</html>