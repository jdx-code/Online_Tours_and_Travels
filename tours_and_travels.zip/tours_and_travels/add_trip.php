<?php
	require_once 'connect.php';

	$car_no    	= $_POST['car_no'];
	$from_city  = $_POST['from_city'];
	$to_city    = $_POST['to_city'];
				 
	$sql = "INSERT INTO trips (trip_id,car_no,from_city,to_city) VALUES (DEFAULT,'$car_no','$from_city','$to_city')";
	$query = mysqli_query($conn,$sql);
?>

