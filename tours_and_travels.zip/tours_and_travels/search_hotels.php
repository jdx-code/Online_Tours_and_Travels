<?php
	session_start();
	require_once 'connect.php';
	$source 	 = $_POST['source'];
	$destination = $_POST['destination'];
	$from 		 = $_POST['from'];
	$to  		 = $_POST['to'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Home Page</title>
<meta charset="UTF-8">
<link href="css/date_picker.css" rel="stylesheet">
<script src="js/jquery.js"></script>
<script src="js/jquery_ui.js"></script>
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">NorthEast Tours</a></h1>
      <h2>Explore the Northeast</h2>
    </div>
    <form action="#" method="post">
      <fieldset>
        <legend>Search:</legend>
        <input type="text" value="Search Our Website&hellip;" onFocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;">
        <input type="submit" id="sf_submit" value="submit">
      </fieldset>
    </form>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Packages</a></li>
        <li><a href="#">Collections</a></li>
        <li><a href="#">services</a></li>
        <li class="last"><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
</div>
<!-- content -->
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- content body -->
    <section id="slider">
      <table class="table table-striped" style="background-color: cyan;border:1px solid blue;">
      <thead>
        <tr>
          <th scope="col">HOTEL</th>
          <th scope="col">CATEGORY</th>
          <th scope="col">TOTAL ROOMS</th>
          <th scope="col">AVAILABLE ROOMS</th>
          <th scope="col">RATE PER ROOM</th>
        </tr>
      </thead>

      <?php
        $sql = "SELECT * FROM cities, hotel_info
          WHERE cities.city_id = '$source' AND hotel_info.city_id = '$destination'";
        $result = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_array($result)){
      ?>

      <tbody>
        <tr>
          <td>
            <?php
              echo $row['hotel_name'];
            ?>
          </td>
          <td>
            <?php
              echo $row['hotel_category'];
            ?>
          </td>
          <td>
            <?php
              echo $row['total_rooms'];
            ?>
          </td>
          <td>
            <?php
              echo $row['available_rooms'];
            ?>
          </td>
          <td>
            <?php
              echo $row['rate_per_room'];
            ?>
          </td>
                        
          <td>
            <a type="button" class="btn btn-danger" href="book_hotel.php?hotel_id=<?php echo $row['hotel_id'];?>&rate_per_room=<?php echo $row['rate_per_room'];?>&from_city=<?php echo $source;?>&to_city=<?php echo $destination;?>">Book Hotel</a>
          </td>               

        <?php
        }
        ?>
        </tr>

      </tbody>
    </table>
    </section>
    <section id="shout">
      <p>
        <form name="search_form" action="search_hotels.php" method="post">
          From :  <select name="source">
                    <option selected="true" disabled="disabled">Select</option>  
                    <?php
                        require_once 'connect.php';
                        $sql   = "SELECT * FROM cities";
                        $result = mysqli_query($conn,$sql);
                     
                        while($row = mysqli_fetch_array($result)){
                          echo '<option value='.$row['city_id'].'>'.$row['city_name'].'</option>';         
                        }
                      ?>                      
                  </select>
          To :    <select name="destination">
                    <option selected="true" disabled="disabled">Select</option>  
                    <?php
                        require_once 'connect.php';
                        $sql   = "SELECT * FROM cities";
                        $result = mysqli_query($conn,$sql);
                     
                        while($row = mysqli_fetch_array($result)){
                          echo '<option value='.$row['city_id'].'>'.$row['city_name'].'</option>';         
                        }
                      ?>                      
                  </select>
  <label for="from">Departure</label>  <input type="text" class="datepicker" id="from" name="from"/> 
  <label for="to">Arrival</label>  <input type="text" class="datepicker" id="to" name="to"/>
  <input type="submit" name="subBtn" value="Search">
</form>
      </p>
    </section>
    <!-- main content -->
    <div id="homepage">      
      
      
    </div>
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">Tours & Travels</a></p>
    <p class="fl_right">Designed for <a target="_blank" href="#" title="Tours & Travels">Tours & Travels</a></p>
  </footer>
</div>
</body>
</html>