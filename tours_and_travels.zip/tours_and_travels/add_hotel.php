<?php
	require_once 'connect.php';

	$hotel_name    	= $_POST['hotel_name'];
	$hotel_category = $_POST['hotel_category'];
	$total_rooms    = $_POST['total_rooms'];
	$rate_per_room  = $_POST['rate_per_room'];
	$city_id    	= $_POST['city_id'];
	$hotel_desc   	= $_POST['hotel_desc'];
	$date_added   	= date('d-m-Y');
			 
	$sql = "INSERT INTO hotel_info (hotel_id,hotel_name,hotel_category,total_rooms,available_rooms,rate_per_room,city_id,hotel_desc,date_added) VALUES (DEFAULT,'$hotel_name','$hotel_category','$total_rooms','$total_rooms','$rate_per_room','$city_id','$hotel_desc','$date_added')";
	$query = mysqli_query($conn,$sql);
?>

