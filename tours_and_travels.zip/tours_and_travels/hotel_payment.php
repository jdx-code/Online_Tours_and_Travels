<?php
  session_start();
  if(!isset($_SESSION["cus_id"])) {
      header("Location:index.php");
      echo "You must be logged in before booking";      
  }

	require_once 'connect.php';


	$cus_id    	  	  = $_POST['cus_id'];
	$hotel_id 	  	  = $_POST['hotel_id'];
	$available_rooms  = $_POST['available_rooms'];
	$rooms_booked 	  = $_POST['rooms_booked'];
	$total_amount 	  = $_POST['total_amount'];
	$date_of_booking  = date('d-m-Y');

	$from_city		  = $_POST['from_city'];
	$to_city		  = $_POST['to_city'];


	$sql = "INSERT INTO hotel_booking (book_id, cus_id, hotel_id, rooms_booked, total_amount, date_of_booking) VALUES (DEFAULT,'$cus_id','$hotel_id','$rooms_booked','$total_amount','$date_of_booking')";
	$query = mysqli_query($conn,$sql);
			 
	$sql1   =  "UPDATE hotel_info SET 
             available_rooms = '$available_rooms' - '$rooms_booked' WHERE hotel_id = '$hotel_id'";
  	$query1 = mysqli_query($conn,$sql1);
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Home Page</title>
<meta charset="UTF-8">
<link href="css/date_picker.css" rel="stylesheet">
<script src="js/jquery.js"></script>
<script src="js/jquery_ui.js"></script>
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">NorthEast Tours</a></h1>
      <h2>Explore the Northeast</h2>
    </div>
    <form action="#" method="post">
      <fieldset>
        <legend>Search:</legend>
        <input type="text" value="Search Our Website&hellip;" onFocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;">
        <input type="submit" id="sf_submit" value="submit">
      </fieldset>
    </form>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Packages</a></li>
        <li><a href="#">Collections</a></li>
        <li><a href="#">services</a></li>
        <li><a href="logout.php"> LOGOUT </a></li>        
      </ul>
    </nav>
  </header>
</div>

<!-- content -->
<div class="wrapper row2">
  <?php echo "WELCOME ".$_SESSION["cus_name"]. ""; ?>
  <div id="container" class="clear">
    <!-- content body -->
    <section id="slider"><a href="#"><img src="images/assam_0.jpg" alt=""></a></section>
    <section id="shout">
      <p>        
        <h3>HOTEL BOOKED SUCCESSFULLY!! </h3>
	<hr>
		<p>
			<a type="button" class="btn btn-danger" href="search_car.php?from_city=<?php echo $from_city;?>&to_city=<?php echo $to_city;?>">Search Cars</a>
		</p>
		<p>
			<a type="button" class="btn btn-danger" href="user_profile.php">Go Back</a>
		</p>
      </p>
    </section>
    <!-- main content -->
    <div id="homepage">
      <!-- services area -->
     
      <section id="services" class="clear">
        
    </div>
    <!-- / content body -->
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">Tours & Travels</a></p>
    <p class="fl_right">Designed for <a target="_blank" href="#" title="Tours & Travels">Tours & Travels</a></p>
  </footer>
</div>
</body>
</html>