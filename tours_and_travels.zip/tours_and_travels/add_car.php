<?php
	require_once 'connect.php';

	$car_no    		= $_POST['car_no'];
	$car_type    	= $_POST['car_type'];
	$car_brand   	= $_POST['car_brand'];
	$car_owner    	= $_POST['car_owner'];
	$owner_ph   	= $_POST['owner_ph'];
	$owner_address  = $_POST['owner_address'];
	$car_driver    	= $_POST['car_driver'];
	$driver_ph   	= $_POST['driver_ph'];
	$driver_address = $_POST['driver_address'];
	$date_added   	= date('d-m-Y');
			 
	$sql = "INSERT INTO cars (car_no,car_type,car_brand,car_owner,owner_ph,owner_address,car_driver,driver_ph,driver_address,date_added,car_status) VALUES ('$car_no','$car_type','$car_brand','$car_owner','$owner_ph','$owner_address','$car_driver','$driver_ph','$driver_address','$date_added','0')";
	$query = mysqli_query($conn,$sql);
?>

