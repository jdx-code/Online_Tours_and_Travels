<?php
  require_once 'connect.php';
  $hotel_id = $_GET['hotel_id'];
  $sql     = "DELETE FROM hotel_info where hotel_id = '$hotel_id'";
  $query   = mysqli_query($conn,$sql);
  header('Location: hotels.php');
?>